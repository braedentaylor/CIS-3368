
#insert into database

from contact import contact
import datetime
from datetime import date
import mysql.connector
from mysql.connector import Error

#database connection messages, used code example from in class #3 2/6

def create_connection(host_name, user_name, user_password, db_name):
    connection = None
    try:
        connection = mysql.connector.connect(
            host=host_name,
            user=user_name,
            passwd=user_password,
            database=db_name
        )
        print("Connection to MySQL DB successful")
    except Error as e:
        print(f"The error '{e}' occurred")

    return connection

def execute_query(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        connection.commit()
        print("Query executed successfully")
    except Error as e:
        print(f"The error '{e}' occurred")

def execute_read_query(connection, query):
    cursor = connection.cursor()
    result = None
    try:
        cursor.execute(query)
        result = cursor.fetchall()
        return result
    except Error as e:
        print(f"The error '{e}' occurred")


#Connection to my database

connection = create_connection("database-homework1.cnmb0sa1zusc.us-east-2.rds.amazonaws.com", "admin", "3368admin!", "dbhw1")

query_select_order_by_creation_date = "select contactDetails, creationDate from contacts order by creationDate;"
contact_raw = execute_read_query(connection, query_select_order_by_creation_date)

contact = [i[0] for i in contact_raw]
creationDate = [[i[1] for i in contact_raw]]
for row in contact_raw:
    print(row[0], row[1])